package com.cakeloop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class homecontroller {
	@RequestMapping("/about")
	 
    public ModelAndView about() {  
        return new ModelAndView("about");
    }
	@RequestMapping("/guesthomepage")
	 
    public ModelAndView guesthomepage() {  
        return new ModelAndView("guesthomepage");
    }
	@RequestMapping("/login")
	 
    public ModelAndView login() {  
        return new ModelAndView("login");
    }
	@RequestMapping("/contact")
	 
    public ModelAndView contact() {  
        return new ModelAndView("contact");
    }
	@RequestMapping("/member")
	 
    public ModelAndView member() {  
        return new ModelAndView("member");
    }
	@RequestMapping("/memberabout")
	 
    public ModelAndView memberabout() {  
        return new ModelAndView("memberabout");
    }
	@RequestMapping("/membercontact")
	 
    public ModelAndView membercontact() {  
        return new ModelAndView("membercontact");
    }
	@RequestMapping("/LoginCheck")
	 
    public ModelAndView LoginCheck() {  
        return new ModelAndView("LoginCheck");
    }
}
	